
</<!DOCTYPE html>
<html>
<head>
   
</head>
<body>

<h1>All Information About Devices</h1>

<?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> <?php echo e($device); ?>  </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h1>Only Names Of Devices</h1>

<?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<li> <?php echo e($device->name); ?>  </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h1>Only Description Of Devices</h1>

<?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<li> <?php echo e($device->description); ?>  </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    
</body>
</html>