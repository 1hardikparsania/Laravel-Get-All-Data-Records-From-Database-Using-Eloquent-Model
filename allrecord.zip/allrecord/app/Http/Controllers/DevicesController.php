<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DevicesController extends Controller
{
    public function index(){

        $devices = \App\Device::all();

        return view('devices.index',compact('devices'));
    }
}
